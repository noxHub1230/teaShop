import React from "react";
import "../styles/home.css";
import { autoBreak } from "../material/tools";
import { waveline, waveline_alt } from "../material/graphy";
const HSContent=[
  {id:"section1_home",
   styleId:"section1_home_style",
   title:"古法傳承",
   text: "堅持遵循傳統製茶工序從採摘、萎凋到焙火，每一步都細心拿捏，只為保留茶葉最純粹的香氣與層次，讓每一口都喝得到時間沉澱出的深厚風味。",
   images:["https://www.chichasanchen.com/blog-detail/upload/fac_b/tw_fac_list_18l21_kfzqr24ip9.jpg",
    "https://image-cdn-flare.qdm.cloud/q65fe4feedb08c/image/data/jjtea/%E9%83%A8%E8%90%BD%E6%A0%BC/%E5%B0%81%E9%9D%A2.jpg",
    "https://edh.tw/_ipx/_/https://media-edh-cdn.h2u.io/image/article/800X418/I26U3XzCU3Dl5VycFxyrTHOoWkctXbpbD59j3uHT.jpg"
   ],
  },
];
function Home() {
  return (
    <div className="container-fluid py-0 px-0">
      <div id="BG" className="container-fluid py-5 px-0">
        <div
          id="title"
          className="d-flex justify-content-center align-items-center"
        ></div>
        <span id="titleText" className="text-center">
          古林萃室 <hr />
          <small id="subtitle">採擷天地精華，品味自然甘醇</small>
        </span>
      </div>
      <div id="contentHome">
        {HSContent.map((section)=>(
        <div className="scrollDistance" id={section.id} key={section.id}>
          <div className="HSsection">
            <div className="HShome" id={section.styleId}>
              <h2>{section.title}</h2>
              <svg
                className="loopWaveLine"
                viewBox="0 -250 6000 500"
                preserveAspectRatio="none"
              >
                <g className="waveGroup">
                  <path d={waveline} />
                  <path d={waveline} transform="translate(3000 0)" />
                </g>
                <g className="waveGroupReverse">
                  <path d={waveline} />
                  <path d={waveline} transform="translate(3000 0)" />
                </g>
              </svg>
              <div className="HStextIntro">
                {autoBreak(section.text)}
              </div>
              <div className="HSImages">
                {section.images.map((image,i)=>(
                <div key={i} className="HSImageItem" style={{"--bg":`url(${image})`}}></div>))
                }
              </div>
            </div>
          </div>
        </div>))
        }
      </div>
    </div>
  );
}

export default Home;
