import React from "react";
import "../styles/home.css";
import { autoBreak } from "../material/tools";
import { waveline, waveline_alt } from "../material/graphy";
function Home() {
  return (
    <div className="container-fluid py-0 px-0">
      <div id="BG" className="container-fluid py-5 px-0">
        <div
          id="title"
          className="d-flex justify-content-center align-items-center"
        ></div>
        <span id="titleText" className="text-center">
          古林萃室 <hr />
          <small id="subtitle">採擷天地精華，品味自然甘醇</small>
        </span>
      </div>
      <div id="contentHome">
        <div className="scrollDistance" id="section1_home">
          <div className="HSsection">
            <div className="HShome" id="section1_home_style">
              <h2>古法傳承</h2>
              <svg
                id="loopWaveLine"
                viewBox="0 -250 6000 500"
                preserveAspectRatio="none"
              >
                <g className="waveGroup">
                  <path d={waveline} />
                  <path d={waveline} transform="translate(3000 0)" />
                </g>
                <g className="waveGroupReverse">
                  <path d={waveline} />
                  <path d={waveline} transform="translate(3000 0)" />
                </g>
              </svg>
              <div className="HStextIntro">
                {autoBreak(
                  "堅持遵循傳統製茶工序從採摘、萎凋到焙火，每一步都細心拿捏，只為保留茶葉最純粹的香氣與層次，讓每一口都喝得到時間沉澱出的深厚風味。",
                )}
              </div>
              <div className="HSImages">
                <div id="HSImage1_home"></div>
                <div id="HSImage2_home"></div>
                <div id="HSImage3_home"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;
